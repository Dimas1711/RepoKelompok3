<div class="well well-lg">
    <div class="container"> 
        <h2>Akun Panti</h2>
        <span>Halaman yang berisi informasi panti.</span>
    </div>
</div>
<div class="container-fluid">
    <div class="card-body">
        <div class="table-responsive">
         <?php foreach($akun as $a){?>
         <p>DETAIL</p>
         <?php }?>
        </div>
    </div>
</div>