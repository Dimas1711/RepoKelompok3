<div class="well well-lg">
    <div class="container">
        <h2>Edit Profile</h2>
    </div>
</div>